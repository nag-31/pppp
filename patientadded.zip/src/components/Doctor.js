import React from 'react'
import Navbar from './NavBar'
import Dashboard from './Dashboard'
const Doctor = () => {
  return (
    <>
    <Navbar/>
    <Dashboard/>
    
    </>
  )
}

export default Doctor