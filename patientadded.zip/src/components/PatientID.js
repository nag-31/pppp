import { useParams } from 'react-router-dom';

const PatientProfile = () => {
  const { patientId } = useParams();
  // Fetch patient data based on patientId
  // Display patient details and vital sign data
};
